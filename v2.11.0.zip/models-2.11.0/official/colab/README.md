# Moved

These files have moved to:
https://github.com/tensorflow/models/blob/master/docs